$(document).ready(function(){
    $('#signin-form').hide();
    $('#signin-form').slideDown(1000);
});